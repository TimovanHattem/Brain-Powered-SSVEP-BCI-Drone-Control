import unittest

import ctypes
from struct import calcsize

from pyardrone.utils.structure import Structure


class SubclassesTest(unittest.TestCase):

    def test_subclass(self):
        class X(Structure):
            a = ctypes.c_int

        class Y(X):
            b = ctypes.c_int

        class Z(X):
            pass

        self.assertEqual(ctypes.sizeof(X), ctypes.sizeof(ctypes.c_int))
        self.assertEqual(ctypes.sizeof(Y), ctypes.sizeof(ctypes.c_int)*2)
        self.assertEqual(ctypes.sizeof(Z), ctypes.sizeof(ctypes.c_int))
        self.assertEqual(X._fields_, [("a", ctypes.c_int)])
        self.assertEqual(Y._fields_, [("b", ctypes.c_int)])
        self.assertEqual(Z._fields_, [("a", ctypes.c_int)])

    def test_subclass_delayed(self):
        class X(Structure):
            pass
        self.assertEqual(ctypes.sizeof(X), 0)
        X._fields_ = [("a", ctypes.c_int)]

        class Y(X):
            pass
        self.assertEqual(ctypes.sizeof(Y), ctypes.sizeof(X))
        Y._fields_ = [("b", ctypes.c_int)]

        class Z(X):
            pass

        self.assertEqual(ctypes.sizeof(X), ctypes.sizeof(ctypes.c_int))
        self.assertEqual(ctypes.sizeof(Y), ctypes.sizeof(ctypes.c_int)*2)
        self.assertEqual(ctypes.sizeof(Z), ctypes.sizeof(ctypes.c_int))
        self.assertEqual(X._fields_, [("a", ctypes.c_int)])
        self.assertEqual(Y._fields_, [("b", ctypes.c_int)])
        self.assertEqual(Z._fields_, [("a", ctypes.c_int)])


class StructureTestCase(unittest.TestCase):

    formats = {"c": ctypes.c_char,
               "b": ctypes.c_byte,
               "B": ctypes.c_ubyte,
               "h": ctypes.c_short,
               "H": ctypes.c_ushort,
               "i": ctypes.c_int,
               "I": ctypes.c_uint,
               "l": ctypes.c_long,
               "L": ctypes.c_ulong,
               "q": ctypes.c_longlong,
               "Q": ctypes.c_ulonglong,
               "f": ctypes.c_float,
               "d": ctypes.c_double,
               }

    def test_simple_structs(self):
        for code, tp in self.formats.items():
            class X(Structure):
                x = ctypes.c_char
                y = tp
            self.assertEqual((ctypes.sizeof(X), code),
                             (calcsize("c%c0%c" % (code, code)), code))

    '''
    def test_unions(self):
        for code, tp in self.formats.items():
            class X(Union):
                _fields_ = [("x", c_char),
                            ("y", tp)]
            self.assertEqual((sizeof(X), code),
                                 (calcsize("%c" % (code)), code))
    '''

    def test_struct_alignment(self):
        class X(Structure):
            x = ctypes.c_char * 3
        self.assertEqual(ctypes.alignment(X), calcsize("s"))
        self.assertEqual(ctypes.sizeof(X), calcsize("3s"))

        class Y(Structure):
            x = ctypes.c_char * 3
            y = ctypes.c_int
        self.assertEqual(ctypes.alignment(Y), ctypes.alignment(ctypes.c_int))
        self.assertEqual(ctypes.sizeof(Y), calcsize("3si"))

        class SI(Structure):
            a = X
            b = Y
        self.assertEqual(ctypes.alignment(SI),
                         max(ctypes.alignment(Y), ctypes.alignment(X)))
        self.assertEqual(ctypes.sizeof(SI), calcsize("3s0i 3si 0i"))

        class IS(Structure):
            b = Y
            a = X

        self.assertEqual(ctypes.alignment(SI),
                         max(ctypes.alignment(X), ctypes.alignment(Y)))
        self.assertEqual(ctypes.sizeof(IS), calcsize("3si 3s 0i"))

        class XX(Structure):
            a = X
            b = X
        self.assertEqual(ctypes.alignment(XX), ctypes.alignment(X))
        self.assertEqual(ctypes.sizeof(XX), calcsize("3s 3s 0s"))

    '''
    def test_emtpy(self):
        # I had problems with these
        #
        # Although these are pathological cases: Empty Structures!
        class X(Structure):
            _fields_ = []

        class Y(Union):
            _fields_ = []

        # Is this really the correct alignment, or should it be 0?
        self.assertTrue(alignment(X) == alignment(Y) == 1)
        self.assertTrue(sizeof(X) == sizeof(Y) == 0)

        class XX(Structure):
            _fields_ = [("a", X),
                        ("b", X)]

        self.assertEqual(alignment(XX), 1)
        self.assertEqual(sizeof(XX), 0)
    '''

    def test_fields(self):
        # test the offset and size attributes of Structure/Unoin fields.
        class X(Structure):
            x = ctypes.c_int
            y = ctypes.c_char

        self.assertEqual(X.x.offset, 0)
        self.assertEqual(X.x.size, ctypes.sizeof(ctypes.c_int))

        self.assertEqual(X.y.offset, ctypes.sizeof(ctypes.c_int))
        self.assertEqual(X.y.size, ctypes.sizeof(ctypes.c_char))

        # readonly
        self.assertRaises(
            (TypeError, AttributeError), setattr, X.x, "offset", 92)
        self.assertRaises(
            (TypeError, AttributeError), setattr, X.x, "size", 92)

        '''
        class X(Union):
            _fields_ = [("x", c_int),
                        ("y", c_char)]

        self.assertEqual(X.x.offset, 0)
        self.assertEqual(X.x.size, sizeof(c_int))

        self.assertEqual(X.y.offset, 0)
        self.assertEqual(X.y.size, sizeof(c_char))

        # readonly
        self.assertRaises(
            (TypeError, AttributeError), setattr, X.x, "offset", 92)
        self.assertRaises(
            (TypeError, AttributeError), setattr, X.x, "size", 92)

        # XXX Should we check nested data types also?
        # offset is always relative to the class...
        '''

    def test_packed(self):
        class X(Structure):
            a = ctypes.c_byte
            b = ctypes.c_longlong
            _pack_ = 1

        self.assertEqual(ctypes.sizeof(X), 9)
        self.assertEqual(X.b.offset, 1)

        class X(Structure):
            a = ctypes.c_byte
            b = ctypes.c_longlong
            _pack_ = 2
        self.assertEqual(ctypes.sizeof(X), 10)
        self.assertEqual(X.b.offset, 2)

        import struct
        longlong_size = struct.calcsize("q")
        longlong_align = struct.calcsize("bq") - longlong_size

        class X(Structure):
            a = ctypes.c_byte
            b = ctypes.c_longlong
            _pack_ = 4
        self.assertEqual(
            ctypes.sizeof(X),
            min(4, longlong_align) + longlong_size
        )
        self.assertEqual(X.b.offset, min(4, longlong_align))

        class X(Structure):
            a = ctypes.c_byte
            b = ctypes.c_longlong
            _pack_ = 8

        self.assertEqual(
            ctypes.sizeof(X),
            min(8, longlong_align) + longlong_size
        )
        self.assertEqual(X.b.offset, min(8, longlong_align))

        d = {"_fields_": [("a", "b"),
                          ("b", "q")],
             "_pack_": -1}
        self.assertRaises(ValueError, type(Structure), "X", (Structure,), d)

        '''
        # Issue 15989
        d = {"_fields_": [("a", c_byte)],
             "_pack_": _testcapi.INT_MAX + 1}
        self.assertRaises(ValueError, type(Structure), "X", (Structure,), d)
        d = {"_fields_": [("a", c_byte)],
             "_pack_": _testcapi.UINT_MAX + 2}
        self.assertRaises(ValueError, type(Structure), "X", (Structure,), d)
        '''

    def test_initializers(self):
        class Person(Structure):
            name = ctypes.c_char * 6
            age = ctypes.c_int

        self.assertRaises(TypeError, Person, 42)
        self.assertRaises(ValueError, Person, b"asldkjaslkdjaslkdj")
        self.assertRaises(TypeError, Person, "Name", "HI")

        # short enough
        self.assertEqual(Person(b"12345", 5).name, b"12345")
        # exact fit
        self.assertEqual(Person(b"123456", 5).name, b"123456")
        # too long
        self.assertRaises(ValueError, Person, b"1234567", 5)

    def test_conflicting_initializers(self):
        class POINT(Structure):
            x = ctypes.c_int
            y = ctypes.c_int
        # conflicting positional and keyword args
        self.assertRaises(TypeError, POINT, 2, 3, x=4)
        self.assertRaises(TypeError, POINT, 2, 3, y=4)

        # too many initializers
        self.assertRaises(TypeError, POINT, 2, 3, 4)

    def test_keyword_initializers(self):
        class POINT(Structure):
            x = ctypes.c_int
            y = ctypes.c_int
        pt = POINT(1, 2)
        self.assertEqual((pt.x, pt.y), (1, 2))

        pt = POINT(y=2, x=1)
        self.assertEqual((pt.x, pt.y), (1, 2))

    def test_intarray_fields(self):
        class SomeInts(Structure):
            a = ctypes.c_int * 4

        # can use tuple to initialize array (but not list!)
        self.assertEqual(list(SomeInts((1, 2)).a[:]), [1, 2, 0, 0])
        self.assertEqual(list(SomeInts((1, 2)).a[::]), [1, 2, 0, 0])
        self.assertEqual(list(SomeInts((1, 2)).a[::-1]), [0, 0, 2, 1])
        self.assertEqual(list(SomeInts((1, 2)).a[::2]), [1, 0])
        self.assertEqual(list(SomeInts((1, 2)).a[1:5:6]), [2])
        self.assertEqual(list(SomeInts((1, 2)).a[6:4:-1]), [])
        self.assertEqual(list(SomeInts((1, 2, 3, 4)).a[:]), [1, 2, 3, 4])
        self.assertEqual(list(SomeInts((1, 2, 3, 4)).a[::]), [1, 2, 3, 4])
        # too long
        # XXX Should raise ValueError?, not RuntimeError
        self.assertRaises(RuntimeError, SomeInts, (1, 2, 3, 4, 5))

    def test_nested_initializers(self):
        # test initializing nested structures
        class Phone(Structure):
            areacode = ctypes.c_char * 6
            number = ctypes.c_char * 12

        class Person(Structure):
            name = ctypes.c_char * 12
            phone = Phone
            age = ctypes.c_int

        p = Person(b"Someone", (b"1234", b"5678"), 5)

        self.assertEqual(p.name, b"Someone")
        self.assertEqual(p.phone.areacode, b"1234")
        self.assertEqual(p.phone.number, b"5678")
        self.assertEqual(p.age, 5)

    '''
    @need_symbol('c_wchar')
    def test_structures_with_wchar(self):
        class PersonW(Structure):
            _fields_ = [("name", c_wchar * 12),
                        ("age", c_int)]

        p = PersonW("Someone \xe9")
        self.assertEqual(p.name, "Someone \xe9")

        self.assertEqual(PersonW("1234567890").name, "1234567890")
        self.assertEqual(PersonW("12345678901").name, "12345678901")
        # exact fit
        self.assertEqual(PersonW("123456789012").name, "123456789012")
        #too long
        self.assertRaises(ValueError, PersonW, "1234567890123")
    '''

    def test_init_errors(self):
        class Phone(Structure):
            areacode = ctypes.c_char * 6
            number = ctypes.c_char * 12

        class Person(Structure):
            name = ctypes.c_char * 12
            phone = Phone
            age = ctypes.c_int

        cls, msg = self.get_except(Person, b"Someone", (1, 2))
        self.assertEqual(cls, RuntimeError)
        self.assertEqual(msg,
                         "(Phone) <class 'TypeError'>: "
                         "expected bytes, int found")

        cls, msg = self.get_except(Person, b"Someone", (b"a", b"b", b"c"))
        self.assertEqual(cls, RuntimeError)
        if issubclass(Exception, object):
            self.assertEqual(
                msg,
                "(Phone) <class 'TypeError'>: too many initializers")
        else:
            self.assertEqual(msg, "(Phone) TypeError: too many initializers")

    def test_huge_field_name(self):
        # issue12881: segfault with large structure field names
        def create_class(length):
            class S(Structure):
                _fields_ = [('x' * length, ctypes.c_int)]

        for length in [10 ** i for i in range(0, 8)]:
            try:
                create_class(length)
            except MemoryError:
                # MemoryErrors are OK, we just don't want to segfault
                pass

    def get_except(self, func, *args):
        try:
            func(*args)
        except Exception as detail:
            return detail.__class__, str(detail)

    @unittest.skip('test disabled')
    def test_subclass_creation(self):
        meta = type(Structure)
        # same as 'class X(Structure): pass'
        # fails, since we need either a _fields_ or a _abstract_ attribute
        cls, msg = self.get_except(meta, "X", (Structure,), {})
        self.assertEqual(
            (cls, msg),
            (AttributeError, "class must define a '_fields_' attribute"))

    def test_abstract_class(self):
        class X(Structure):
            _abstract_ = "something"
        # try 'X()'
        cls, msg = self.get_except(eval, "X()", locals())
        self.assertEqual((cls, msg), (TypeError, "abstract class"))

    '''
    def test_methods(self):
##        class X(Structure):
##            _fields_ = []

        self.assertIn("in_dll", dir(type(Structure)))
        self.assertIn("from_address", dir(type(Structure)))
        self.assertIn("in_dll", dir(type(Structure)))
    '''

    def test_positional_args(self):
        # see also http://bugs.python.org/issue5042
        class W(Structure):
            a = ctypes.c_int
            b = ctypes.c_int

        class X(W):
            c = ctypes.c_int

        class Y(X):
            pass

        class Z(Y):
            d = ctypes.c_int
            e = ctypes.c_int
            f = ctypes.c_int

        z = Z(1, 2, 3, 4, 5, 6)
        self.assertEqual((z.a, z.b, z.c, z.d, z.e, z.f),
                         (1, 2, 3, 4, 5, 6))
        z = Z(1)
        self.assertEqual((z.a, z.b, z.c, z.d, z.e, z.f),
                         (1, 0, 0, 0, 0, 0))
        self.assertRaises(TypeError, lambda: Z(1, 2, 3, 4, 5, 6, 7))

'''
class PointerMemberTestCase(unittest.TestCase):

    def test(self):
        # a Structure with a POINTER field
        class S(Structure):
            _fields_ = [("array", POINTER(c_int))]

        s = S()
        # We can assign arrays of the correct type
        s.array = (c_int * 3)(1, 2, 3)
        items = [s.array[i] for i in range(3)]
        self.assertEqual(items, [1, 2, 3])

        # The following are bugs, but are included here because the unittests
        # also describe the current behaviour.
        #
        # This fails with SystemError: bad arg to internal function
        # or with IndexError (with a patch I have)

        s.array[0] = 42

        items = [s.array[i] for i in range(3)]
        self.assertEqual(items, [42, 2, 3])

        s.array[0] = 1

##        s.array[1] = 42

        items = [s.array[i] for i in range(3)]
        self.assertEqual(items, [1, 2, 3])

    def test_none_to_pointer_fields(self):
        class S(Structure):
            _fields_ = [("x", c_int),
                        ("p", POINTER(c_int))]

        s = S()
        s.x = 12345678
        s.p = None
        self.assertEqual(s.x, 12345678)
'''


class TestRecursiveStructure(unittest.TestCase):

    def test_contains_itself(self):
        class Recursive(Structure):
            pass

        try:
            Recursive._fields_ = [("next", Recursive)]
        except AttributeError as details:
            self.assertIn("Structure or union cannot contain itself",
                          str(details))
        else:
            self.fail("Structure or union cannot contain itself")

    def test_vice_versa(self):

        class First(Structure):
            pass

        class Second(Structure):
            pass

        First._fields_ = [("second", Second)]

        try:
            Second._fields_ = [("first", First)]
        except AttributeError as details:
            self.assertIn("_fields_ is final", str(details))
        else:
            self.fail("AttributeError not raised")


if __name__ == '__main__':
    unittest.main()
