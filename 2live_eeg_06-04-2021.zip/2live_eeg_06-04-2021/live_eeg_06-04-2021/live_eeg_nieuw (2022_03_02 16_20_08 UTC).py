import os
import time
import numpy as np
import pandas as pd
from drone import Drone
from collections import Counter

# import CSV file
#TODO: translate DIO's to numbers from MAPPING
# idee om dit te doen
# als file[1,1] == 1: dan 'prediction.txt' bestaat uit de char/int 3 (voor forward in MAPPING)
#import 'python_input.txt'

# teveel commands for de DIO's maar hoeft niet erg te zijn want we kunnen zelf een nummer/command
# aan de DIO's hangen, dus niet alles hoeft gebruikt te worden
MAPPING = { '1': 'takeoff',
            '2': 'land',
            '3': 'forward',
            '4': 'backward',
            '5': 'rotate_left',
            '6': 'rotate_right',
            '7': 'up',
            '8': 'down',
            '9': 'stop'}
DRONE = None
route_list = [] #None
route_index = 0

# error, land
def handle_signint(signum, frame):
    DRONE.land()

""""""

def read_delete_when_available(filename):
    while not os.path.exists(filename):
        time.sleep(0.05)
    time.sleep(1) #TODO change this number?
    data = np.loadtxt(filename)
    while True:
        try:
            #TODO unsilence!
           #os.remove(filename)
            break
        except:
            continue
    int_array = data.astype(int)
    most_common = np.bincount(int_array).argmax()
    return most_common

# the DIO's have to be 'translated' to a predicted command in prediction.txt
def periodically_classify(route_index=None, route_list=None, filename='python_input.txt'):
    new_input = []
    while True:
        command = read_delete_when_available(filename)
        move_drone(command,route_index,route_list)


def move_drone(command,route_index=None,route_list=None):
    if 0 < command < 10:
        print("Predicted {}".format(MAPPING[str(command)]))
        # route_index += 1
        if DRONE != None:
            if command == 10:
                print('You frowned, stop drone!')
            else:
                print("Moving drone!")
            # print(MAPPING[command]) # dit is alleen printen hoe hij zou bewegen
            # hier onder is daadwerkelijk bewegen
            DRONE.move(MAPPING[str(command)])
            # if route_list:
            #     if route_list[route_index] == command:
            #         DRONE.move(MAPPING[str(command)])
        time.sleep(4) #TODO: Maybe change to less sleep?
        return True
    else:
        print("No classification")
    time.sleep(4) #TODO: Maybe change to less sleep?
    return False

if __name__ == '__main__':
    periodically_classify()
    try:
        DRONE = Drone()
        print("Classifying each second")
        # DRONE.takeoff()
        periodically_classify(route_index, route_list)
    except Exception as e:
        print(e)
        # handle_signint(1, 1)
