#! /usr/bin/env python3
# Communication with drone
# Created by Derk Barten and Devin Hillenius, adjusted for Brain Powered 2020-2021
# UvA Brain Powered 2020-2021

from pyardrone import ARDrone, at
from time import sleep, time


class Drone(object):
    def __init__(self):
        self.d = ARDrone()
        self.d.navdata_ready.wait()

    def takeoff(self):
        """Start flying the drone."""
        self.d.takeoff()

    def land(self):
        """Land the drone."""
        self.d.land()

    def move(self, direction):
        """
        Move the drone forward or backward or rotate the drone for 't' seconds.
        The 'direction' argument can be:
            - 'forward': move forward
            - 'backward': move backward
            - 'rotate_right': rotate 90 degrees to the right
            - 'rotate_left': rotate 90 degrees to the left
            - 'up': move upwards
            - 'down': move downwards
            - 'stop': stop drone when frown

        """
        if direction == 'forward':
            self.forward(t=2)
        elif direction == 'backward':
            self.backward(t=1)
        elif direction == 'rotate_right':
            self.cw(t=0.4)
        elif direction == 'rotate_left':
            self.ccw(t=0.4)
        elif direction == 'up':
            self.up(t=1)
        elif direction == 'down':
            self.down(t=1)

        # when frowned, stop drone and let it hover
        elif direction == 'stop':
            self.d.hover()
        else:
            raise ValueError(
                'Given direction {} not supported!'.format(direction))
        self.d.hover()

    def forward(self, t=0.3, s=0.1):
        t_end = time() + t
        while time() < t_end:
            self.d.move(forward=s)

    def backward(self, t=0.3, s=0.1):
        t_end = time() + t
        while time() < t_end:
            self.d.move(backward=s)

    # rotate right
    def cw(self, t=0.08, s=0.8):
        t_end = time() + t
        while time() < t_end:
            self.d.move(cw=s)

    # rotate left
    def ccw(self, t=0.08, s=0.8):
        t_end = time() + t
        while time() < t_end:
            self.d.move(ccw=s)

    # move up
    # s is speed, so s=1 and up=s means upward with full speed
    # t is time, so the higher t, the longer the movement will be executed
    def up(self, t=0.3, s=0.3): #TODO: adjust these parameters for up
        t_end = time() + t
        while time() < t_end:
            self.d.move(up=s)

    # move up
    def down(self, t=0.3, s=0.3):  #TODO: adjust these parameters for down
        t_end = time() + t
        while time() < t_end:
            self.d.move(down=s)


if __name__ == '__main__':
    try:
            DRONE = Drone()
            
            DRONE.takeoff()
            sleep(2)
            DRONE.move('forward')
            sleep(2)
            DRONE.land()
            sleep(2)
            quit()
    except Exception as e:
        print(e)
        DRONE = None
        # handle_signint(1, 1)